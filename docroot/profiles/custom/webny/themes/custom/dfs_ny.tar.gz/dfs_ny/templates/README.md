# This is the Templates folder

The templates which came with the dfs_ny from Acquia are now in the readme folder of the repo - top level. They and other templates will be added here as we need them in the development of the dfs_ny.

As a side note, the dfs_ny.info.yml file (in the main theme directory) had these regions removed from it (they relate to the templates removed):

regions:
  branding: Branding
  header: Header
  pre_content: Pre Content
  content: Content
  sidebar_first: 'Sidebar first'
  sidebar_second: 'Sidebar second'
  post_content: Post Content
  footer: Footer